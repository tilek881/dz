// Задание 1

var str = "*";
while (str.length<=7) {
    console.log(str + "\n");
    str += "*"
}
//     length<7
// for (var pk ="*"; )
// for (var pk ="*"; pk.length<7; pk+="*");
// }









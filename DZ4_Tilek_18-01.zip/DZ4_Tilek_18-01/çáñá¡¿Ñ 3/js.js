// Задание 3
function createChess(a, b) {
  var value1 = " #";
  var value2 = "# ";
  var odd = "";
  var even = "";
  for (var i = 0; i < a / 2; i += 1) {
    odd += value2;
    even += value1;
  }

  for (var j = 0; j < b; j += 1) {
    if (j % 2 != 1) {
      console.log(odd);
    } else {
      console.log(even);
    }
  }
}

createChess(9, 6);